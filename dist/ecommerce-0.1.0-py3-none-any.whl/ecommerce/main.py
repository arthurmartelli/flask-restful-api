def main():
    print("Hi!")
    return None
