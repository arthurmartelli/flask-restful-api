## Acknowledgments

This project was built with inspiration on:

- http://blog.luisrei.com/articles/rest.html
- http://blog.luisrei.com/articles/flaskrest.html

## Uses

- poetry add --group dev poethepoet
